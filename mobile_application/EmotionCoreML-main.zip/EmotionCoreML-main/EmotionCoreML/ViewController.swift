//
//  ViewController.swift
//  EmotionCoreML
//
//  Created by Michael Guel on 11/21/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

