//
//  EmotionCoreMLTests.swift
//  EmotionCoreMLTests
//
//  Created by Michael Guel on 11/21/24.
//

import Testing
@testable import EmotionCoreML

struct EmotionCoreMLTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
